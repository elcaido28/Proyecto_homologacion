<?php
include('menu.php');
/*include('conexion.php');*/
?>
<div class="fondoimg">

<img src="imagenes/banner11.jpg" alt="" class="img_inicioF">
</div>


</div>
</div>
  </body>
</html>
