<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>APP UAE</title>
      <link rel="stylesheet" href="../estilos_login.css">
  </head>
  <body>
    <center><br><br><br><br><br><br><br>
    <div class="bord">

      <img src="../icono_uae.png" class="logo_login" alt="">
      <section class="formulario1">
        <p class="titulo_from">INICIO DE SESIÓN ESTUDIANES</p>
        <form class="con_form" action="login.php" method="post">
          <input type="text" autofocus id="N" class="cajapeque" name="nomUsu" placeholder="Nº de solicitud" value="">
          <input type="password" id="P" class="cajapeque" name="contrasena" placeholder="Cedula">
          <input type="submit" class="aceptar2" name="ingresar" value="INGRESAR">
        </form>
      </section>
    </div>
    </center>
  </body>
</html>
