$(buscar_datos());
function buscar_datos(consulta) {
  $.ajax({
    url:'ver_progreso.php',
    type: 'POST',
    dataType: 'php',
    data:{consulta:consulta},
  })
  .done(function(respuesta) {
    $(".progreso").php(respuesta);
  })

}
