<?php
session_start();
include('../conexion.php');
$cedula=$_SESSION['CEDU'];
$result= mysqli_query($con,"SELECT * from solicitantes where Cedula='$cedula'");
$row= mysqli_fetch_assoc($result);
$ano_actual=date(Y);
$ano=$ano_actual-$row['ult_ano'];
if($ano<=5){
  $result2= mysqli_query($con,"SELECT * from solicitantes S inner join homologacion H on H.id_solicitud=S.id_solicitud inner join resolucionh RH on RH.id_homologacio=H.id_homologacion where S.Cedula='$cedula'");
  $row2= mysqli_fetch_assoc($result2);

  $salida="<img src='img/progreso_secretaria.png' alt=''>";

  if($row['estado1']=="EN CURSO"){
    $salida="<img src='img/progreso_ProfesorD.png' alt=''>";
  }elseif($row['estado1']=="FINALIZADA" and $row['estado2']=="FINALIZADA"){
  $salida="<img src='img/progreso_consejo.png' alt=''>";
}elseif($row['estadoRH']=="FINALIZADA"){
  $salida="<img src='img/progreso_fin.png' alt=''>";
}else{
  $salida="<img src='img/progreso_secretaria.png' alt=''>";
}
}else{
  $result2= mysqli_query($con,"SELECT * from solicitantes S inner join homologacion H on H.id_solicitud=S.id_solicitud inner join resolucionh RH on RH.id_homologacio=H.id_homologacion where S.Cedula='$cedula'");
  $row2= mysqli_fetch_assoc($result2);

  $salida="<img src='img/progreso_secretaria.png' alt=''>";

  if($row['estado1']=="EN CURSO"){
    $salida="<img src='img/progreso_ProfesorD.png' alt=''>";
  }elseif($row['estado1']=="FINALIZADA" and $row['estado2']=="FINALIZADA"){
  $salida="<img src='img/progreso_consejo.png' alt=''>";
}elseif($row['estadoRH']=="FINALIZADA"){
  $salida="<img src='img/progreso_fin.png' alt=''>";
}else{
  $salida="<img src='img/progreso_secretaria.png' alt=''>";
}
}
echo $salida;
 ?>
