<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Progreso de Tramites</title>
    <link rel="stylesheet" href="estilo_progreso.css">
  </head>
  <body>
    <nav class="nav1">
      <header class="header2">
      <div class="wrapper">
      	<div class="logo"> <a href="#"><img src="../icono_uae.png" href="#.php" class="logo_uae"></a>  </div>
        <div class="menu-logo">
          <a href="#"><i class="fa fa-user" aria-hidden="true"></i><?php echo " ".$_SESSION['ES_USU']; ?></a>
        </div>
      </div>
      </header>
    </nav>
    <section>
      <div class="conten_progreso">
        <div class="titulo2">

          <p>Progreso del Tramite</p>

        </div>
        <div class="progreso">
          
        </div>
      </div>
    </section>
  </body>
</html>
